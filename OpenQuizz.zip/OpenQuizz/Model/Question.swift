//
//  Question.swift
//  OpenQuizz
//
//  Created by Stephane Gabillet on 30/09/2019.
//  Copyright © 2019 Stephane Gabillet. All rights reserved.
//

import Foundation

struct Question {
    
    var title = ""
    var isCorrect = false
    
    
}
